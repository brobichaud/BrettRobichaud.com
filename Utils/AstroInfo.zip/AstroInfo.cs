using System;

namespace RobiSoft.WeatherNet
{
	/// <summary>
	/// Calculates astrological information based on latitude and longitude.
	/// All dates are returned in local time.
	/// </summary>
	public class CAstrologicalInfo
	{
		private static double PI = 3.1415926;
		private double m_dLatitude;
		private double m_dLongitude;
		private DateTime m_tDate;

		// Normalize values to range 0 to 1
		private double Normalize(double V)
		{
			V=V-(int)(V);
			if (V<0)
				V++;
				
			return V;
		}
										  
		// don't allow empty constructor use
		private CAstrologicalInfo()
		{
		}
		
		public CAstrologicalInfo(double dLat, double dLon, DateTime time)
		{
			m_dLatitude = dLat;
			m_dLongitude = dLon;
			m_tDate = time;
		}
		
		public DateTime Sunrise
		{
			get
			{
				int iJulianDay = JulianDay;
				double timeGMT = calcSunriseGMT(iJulianDay, m_dLatitude, m_dLongitude); 

				// if Northern hemisphere and spring or summer, use last sunrise and next sunset
				if ((m_dLatitude > 66.4) && (iJulianDay > 79) && (iJulianDay < 267))
					timeGMT = findRecentSunrise(iJulianDay, m_dLatitude, m_dLongitude);
					// if Northern hemisphere and fall or winter, use next sunrise and last sunset
				else if ((m_dLatitude > 66.4) && ((iJulianDay < 83) || (iJulianDay > 263)))
					timeGMT = findNextSunrise(iJulianDay, m_dLatitude, m_dLongitude);
					// if Southern hemisphere and fall or winter, use last sunrise and next sunset
				else if((m_dLatitude < -66.4) && ((iJulianDay < 83) || (iJulianDay > 263)))
					timeGMT = findRecentSunrise(iJulianDay, m_dLatitude, m_dLongitude);
					// if Southern hemisphere and spring or summer, use next sunrise and last sunset
				else if((m_dLatitude < -66.4) && (iJulianDay > 79) && (iJulianDay < 267))
					timeGMT = findNextSunrise(iJulianDay, m_dLatitude, m_dLongitude);
		
				double dHour = timeGMT / 60;
				int iHour = (int)dHour;
				double dMinute = 60 * (dHour - iHour);
				int iMinute = (int)dMinute;
				double dSecond = 60 * (dMinute - iMinute);
				int iSecond = (int)dSecond;
		
				// offset the hours based on UTC
				iHour += TimeZone.CurrentTimeZone.GetUtcOffset(DateTime.Now).Hours;

				return new DateTime(m_tDate.Year, m_tDate.Month, m_tDate.Day, iHour, iMinute, iSecond);
			}
		}
		
		public DateTime Sunset
		{
			get
			{
				int iJulianDay = JulianDay;
				double timeGMT = calcSunsetGMT(iJulianDay, m_dLatitude, m_dLongitude); 

				// if Northern hemisphere and spring or summer, use last sunrise and next sunset
				if ((m_dLatitude > 66.4) && (iJulianDay > 79) && (iJulianDay < 267))
					timeGMT = findRecentSunset(iJulianDay, m_dLatitude, m_dLongitude);
					// if Northern hemisphere and fall or winter, use next sunrise and last sunset
				else if ((m_dLatitude > 66.4) && ((iJulianDay < 83) || (iJulianDay > 263)))
					timeGMT = findNextSunset(iJulianDay, m_dLatitude, m_dLongitude);
					// if Southern hemisphere and fall or winter, use last sunrise and next sunset
				else if((m_dLatitude < -66.4) && ((iJulianDay < 83) || (iJulianDay > 263)))
					timeGMT = findRecentSunset(iJulianDay, m_dLatitude, m_dLongitude);
					// if Southern hemisphere and spring or summer, use next sunrise and last sunset
				else if((m_dLatitude < -66.4) && (iJulianDay > 79) && (iJulianDay < 267))
					timeGMT = findNextSunset(iJulianDay, m_dLatitude, m_dLongitude);
		
				double dHour = timeGMT / 60;
				int iHour = (int)dHour;
				double dMinute = 60 * (dHour - iHour);
				int iMinute = (int)dMinute;
				double dSecond = 60 * (dMinute - iMinute);
				int iSecond = (int)dSecond;

				// offset the hours based on UTC
				iHour += TimeZone.CurrentTimeZone.GetUtcOffset(DateTime.Now).Hours;

				return new DateTime(m_tDate.Year, m_tDate.Month, m_tDate.Day, iHour, iMinute, iSecond);
			}
		}
		
		public DateTime SolarNoon
		{
			get
			{
				int iJulianDay = JulianDay;
				double timeGMT = calcSolNoonGMT(iJulianDay, m_dLongitude); 

				double dHour = timeGMT / 60;
				int iHour = (int)dHour;
				double dMinute = 60 * (dHour - iHour);
				int iMinute = (int)dMinute;
				double dSecond = 60 * (dMinute - iMinute);
				int iSecond = (int)dSecond;
		
				// offset the hours based on UTC
				iHour += TimeZone.CurrentTimeZone.GetUtcOffset(DateTime.Now).Hours;

				return new DateTime(m_tDate.Year, m_tDate.Month, m_tDate.Day, iHour, iMinute, iSecond);
			}
		}
		
		public int MoonPhase
		{
			get
			{
				double P2 = 2*PI;
				int nYY = m_tDate.Year - (int)((12-m_tDate.Month)/10);
				int nMM = m_tDate.Month+9;
				if (nMM >= 12)
					nMM -= 12;

				// J is the Julian date at 12h UT on day in question
				int nK1 = (int)(365.25 * (nYY + 4712));
				int nK2 = (int)(30.6 * nMM + .5);
				int nK3 = (int)((int)((nYY/100)+49)*.75) - 38;
				int nJ = nK1 + nK2 + m_tDate.Day + 59; // JD for dates in Julian calendar
				if (nJ > 2299160)
					nJ -= nK3; // For Gregorian calendar

				// Calculate illumination (synodic) phase
				double dV = (nJ-2451550.1) / 29.530588853;
				dV = Normalize(dV);
				double dAG = dV*29.53; // Moon's age in days

				return (int)dAG;
			}
		}

		public bool IsLeapYear
		{
			get
			{
				return ((m_tDate.Year % 4 == 0 && m_tDate.Year % 100 != 0) || m_tDate.Year % 400 == 0);
			}
		}

		public string GetDateStringFromJulianDay(int jday, bool bLeapYear)
		{
			int day = jday;
			int mon = 0;

			if (bLeapYear) 
			{
				for (int i = 0; i < 12; i ++) 
				{
					if (day > leapList[i].m_iNumDays)
					{
						mon ++;
						day -= leapList[i].m_iNumDays;
					}
				}
			}
			else
			{
				for (int i = 0; i < 12; i ++) 
				{
					if (day > monthList[i].m_iNumDays)
					{
						mon ++;
						day -= monthList[i].m_iNumDays;
					}
				}
			}
		
			return monthList[mon].m_sName + " " + day.ToString();
		}

		public int JulianDay
		{
			get
			{
				int iJulDay = 0;

				if (IsLeapYear)
				{
					for (int i = 0; i < m_tDate.Month - 1 ; i++)
						iJulDay += leapList[i].m_iNumDays;
				}
				else
				{
					for (int i = 0; i < m_tDate.Month - 1; i++)
						iJulDay += monthList[i].m_iNumDays;
				}

				iJulDay += m_tDate.Day;

				return iJulDay;
			}
		}

		//	Convert radian angle to degrees
		private double dRadToDeg(double dAngleRad)
		{
			return (180 * dAngleRad / PI);
		}

		//	Convert degree angle to radians
		private double dDegToRad(double dAngleDeg)
		{
			return (PI * dAngleDeg / 180);
		}

		private double CalcGamma(int iJulianDay)
		{
			return (2 * PI / 365) * (iJulianDay - 1);	
		}

		private double CalcGamma2(int iJulianDay, int iHour)
		{
			return (2 * PI / 365) * (iJulianDay - 1 + (iHour/24));
		}

		private double CalcEqofTime(double dGamma)
		{
			return (229.18 * (0.000075 + 0.001868 * Math.Cos(dGamma) - 0.032077 * Math.Sin(dGamma)- 0.014615 * Math.Cos(2 * dGamma) - 0.040849 *  Math.Sin(2 * dGamma)));
		}
	
		private double CalcSolarDec(double dGamma)
		{
			return (0.006918 - 0.399912 * Math.Cos(dGamma) + 0.070257 * Math.Sin(dGamma) - 0.006758 * Math.Cos(2 * dGamma) + 0.000907 *  Math.Sin(2 * dGamma));
		}

		//	Return the length of the day in minutes.
		private int CalcDayLength(double dHourAngle)
		{
			return (int)((2 * Math.Abs(dRadToDeg(dHourAngle))) / 15);
		}
		
		private double CalcHourAngle(double dLat, double dSolarDec, bool bTime)
		{
			double dLatRad = dDegToRad(dLat);
			if (bTime)  //Sunrise
				return  (Math.Acos(Math.Cos(dDegToRad(90.833))/(Math.Cos(dLatRad)*Math.Cos(dSolarDec))-Math.Tan(dLatRad) * Math.Tan(dSolarDec)));
			else
				return -(Math.Acos(Math.Cos(dDegToRad(90.833))/(Math.Cos(dLatRad)*Math.Cos(dSolarDec))-Math.Tan(dLatRad) * Math.Tan(dSolarDec)));		
		}
	
		private double calcSunsetGMT(int iJulDay, double dLatitude, double dLongitude)
		{
			// First calculates sunrise and approx length of day
			double dGamma = CalcGamma(iJulDay + 1);
			double eqTime = CalcEqofTime(dGamma);
			double solarDec = CalcSolarDec(dGamma);
			double hourAngle = CalcHourAngle(dLatitude, solarDec, false);
			double delta = dLongitude - dRadToDeg(hourAngle);
			double timeDiff = 4 * delta;
			double setTimeGMT = 720 + timeDiff - eqTime;

			// first pass used to include fractional day in gamma calc
			double gamma_sunset = CalcGamma2(iJulDay, (int)setTimeGMT/60);
			eqTime = CalcEqofTime(gamma_sunset);


			solarDec = CalcSolarDec(gamma_sunset);
	
			hourAngle = CalcHourAngle(dLatitude, solarDec, false);
			delta = dLongitude - dRadToDeg(hourAngle);
			timeDiff = 4 * delta;
			setTimeGMT = 720 + timeDiff - eqTime; // in minutes

			return setTimeGMT;
		}

		private double calcSunriseGMT(int iJulDay, double dLatitude, double dLongitude)
		{
			// *** First pass to approximate sunrise

			double gamma = CalcGamma(iJulDay);
			double eqTime = CalcEqofTime(gamma);
			double solarDec = CalcSolarDec(gamma);
			double hourAngle = CalcHourAngle(dLatitude, solarDec, true);
			double delta = dLongitude - dRadToDeg(hourAngle);
			double timeDiff = 4 * delta;
			double timeGMT = 720 + timeDiff - eqTime;

			// *** Second pass includes fractional jday in gamma calc

			double gamma_sunrise = CalcGamma2(iJulDay, (int)timeGMT/60);
			eqTime = CalcEqofTime(gamma_sunrise);
			solarDec = CalcSolarDec(gamma_sunrise);
			hourAngle = CalcHourAngle(dLatitude, solarDec, true);
			delta = dLongitude - dRadToDeg(hourAngle);
			timeDiff = 4 * delta;
			timeGMT = 720 + timeDiff - eqTime; // in minutes

			return timeGMT;
		}
		
		private double calcSolNoonGMT(int iJulDay, double dLongitude)
		{
			// Adds approximate fractional day to julday before calc gamma

			double gamma_solnoon = CalcGamma2(iJulDay, 12 + (int)(dLongitude/15));
			double eqTime = CalcEqofTime(gamma_solnoon);
			double solarNoonDec = CalcSolarDec(gamma_solnoon);
			double solNoonGMT = 720 + (dLongitude * 4) - eqTime; // min
	
			return solNoonGMT;
		}

		private double findRecentSunrise(int iJulDay, double dLatitude, double dLongitude)
		{
			int jday = iJulDay;

			double dTime = calcSunriseGMT(jday, dLatitude, dLongitude);
	
			while(!IsInteger(dTime) )
			{
				jday--;
				if (jday < 1) 
					jday = 365;
				dTime = calcSunriseGMT(jday, dLatitude, dLongitude);
			}

			return jday;
		}

		private double findRecentSunset(int iJulDay, double dLatitude, double dLongitude)
		{
			int jday = iJulDay;

			double dTime = calcSunsetGMT(jday, dLatitude, dLongitude);
	
			while(!IsInteger(dTime) )
			{
				jday--;
				if (jday < 1) 
					jday = 365;
				dTime = calcSunsetGMT(jday, dLatitude, dLongitude);
			}

			return jday;
		}

		private double findNextSunrise(int iJulDay, double dLatitude, double dLongitude)
		{
			int jday = iJulDay;

			double dTime = calcSunriseGMT(jday, dLatitude, dLongitude);
	
			while(!IsInteger(dTime) )
			{
				jday++;
				if (jday > 366) 
					jday = 1;
				dTime = calcSunriseGMT(jday, dLatitude, dLongitude);
			}

			return jday;
		}

		private double findNextSunset(int iJulDay, double dLatitude, double dLongitude)
		{
			int jday = iJulDay;

			double dTime = calcSunsetGMT(jday, dLatitude, dLongitude);
	
			while(!IsInteger(dTime) )
			{
				jday++;
				if (jday > 366) 
					jday = 1;
				dTime = calcSunsetGMT(jday, dLatitude, dLongitude);
			}

			return jday;
		}

		private bool IsInteger(double dValue)
		{
			int iTemp = (int)dValue;
			double dTemp = dValue - iTemp;
			if (dTemp == 0)
				return true;
			else
				return false;
		}

		public class CMonth
		{
			public int m_iNumDays;
			public string m_sName;

			public CMonth(string sName, int iNumDays)
			{
				m_iNumDays = iNumDays;
				m_sName = sName;
			}
		}	

		private static CMonth[] monthList=
		{
			new CMonth("January", 31),
			new CMonth("February", 28),
			new CMonth("March", 31),
			new CMonth("April", 30),
			new CMonth("May", 31),
			new CMonth("June", 30),
			new CMonth("July", 31),
			new CMonth("August", 31),
			new CMonth("September", 30),
			new CMonth("October", 31),
			new CMonth("November", 30),
			new CMonth("December", 31)
		};

		private static CMonth[] leapList =
		{
			new CMonth("January", 31),
			new CMonth("February", 29),
			new CMonth("March", 31),
			new CMonth("April", 30),
			new CMonth("May", 31),
			new CMonth("June", 30),
			new CMonth("July", 31),
			new CMonth("August", 31),
			new CMonth("September", 30),
			new CMonth("October", 31),
			new CMonth("November", 30),
			new CMonth("December", 31)
		};
	}
}
